
DROP INDEX idx_order_items_product_id;
DROP INDEX idx_order_items_order_id;
DROP INDEX idx_orders_customer_id;
DROP INDEX idx_orders_user_id;
DROP INDEX idx_customers_email;
DROP INDEX idx_customers_user_id;
DROP INDEX idx_products_active;
DROP INDEX idx_products_category;
DROP INDEX idx_products_user_id;
DROP TABLE order_items;
DROP TABLE orders;
DROP TABLE customers;
DROP TABLE products;
